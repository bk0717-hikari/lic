
input_image = (1, 3, 256, 256)
x = input_image.view(1, 3, 256*256).permute(0, 2, 1)
print(x)