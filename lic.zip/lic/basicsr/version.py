# GENERATED VERSION FILE
# TIME: Tue Mar  5 05:49:10 2024
__version__ = '1.4.2'
__gitsha__ = 'unknown'
version_info = (1, 4, 2)
